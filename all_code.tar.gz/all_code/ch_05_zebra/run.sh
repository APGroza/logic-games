#prover9 -f day11p.in  | prooftrans xml renumber | gvizify | dot -Tpdf > day11p.pdf
#mace4 -f magisterialbench.in | interpformat standard > magisterialbench.out
#mace4 -f ships.in | interpformat standard > ships.out
#mace4 -f ladiescommittee3.in | interpformat standard > ladiescommittee3.out
#mace4 -f cocktailparty.in | interpformat standard > cocktailparty.out
#mace4 -f borrowedbooks.in | interpformat standard > borrowedbooks.out
#mace4 -f baseballdilemma.in | interpformat standard > baseballdilemma.out
#mace4 -f perfectman3.in | interpformat standard > perfectman3.out
#mace4 -f bikers4.in | interpformat standard > bikers4.out
#mace4 -f moviesnight2.in | interpformat standard > moviesnight2.out
#mace4 -f secretSanta2.in | interpformat standard > secretSanta2.out
#mace4 -f partyseating.in | interpformat standard > partyseating.out
mace4 -f p265_passengers.in | interpformat standard > p265_passengers.out

