#mace4 -f romeojulieta.in | interpformat standard > romeojulieta.out
#mace4 -f addingcubes.in | interpformat standard > adddingcubes.out
#mace4 -f multiplication.in | interpformat standard > multiplication.out
#mace4 -f arithmeticalcabby.in | interpformat standard > arithmeticalcabby.out
#mace4 -f tenbarrels.in | interpformat standard > tenbarrels.out
#mace4 -f trianglearea.in | interpformat standard > trianglearea.out
#mace4 -f digitaldifficulty.in | interpformat standard > digitaldifficulty.out
#mace4 -f archerymatch.in | interpformat standard > archerymatch.out
#mace4 -f targetpractice.in | interpformat standard > targetpractice.out
#mace4 -f ninebarrels.in | interpformat standard > ninebarrels.out
#mace4 -f upsideyearb.in | interpformat standard > upsideyearb.out
#mace4 -f rotate.in | interpformat standard > rotate.out
mace4 -f unusualnumber.in | interpformat standard > unusualnumber.out

